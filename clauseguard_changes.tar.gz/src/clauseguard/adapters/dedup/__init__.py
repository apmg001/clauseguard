"""Duplicate-detection adapters."""
